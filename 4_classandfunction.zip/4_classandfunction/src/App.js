import logo from './logo.svg';
import './App.css';
import myclasscomponent from './components/myclasscomponent';
import myfunctioncomponent from './components/myfunctioncomponent';

function App() {
  return (
    <div className="App">
      <h2>kamran saiyed</h2>
    </div>
  );
}

export default App;
