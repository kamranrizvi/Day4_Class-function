import React from "react";

class myclasscomponent extends React.Component{
    return(){<h2>custom class components</h2>}
    
}