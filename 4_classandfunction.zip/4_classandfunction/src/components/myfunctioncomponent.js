function myfunctioncomponent(){
    return (<h2>my function component</h2>);
    }
    export default myfunctioncomponent;